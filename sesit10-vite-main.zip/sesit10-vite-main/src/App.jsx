
import './App.css'

function App() {

  return (
    <>
      <h1>Ola mundo!</h1>
    </>
  )
}

export default App
